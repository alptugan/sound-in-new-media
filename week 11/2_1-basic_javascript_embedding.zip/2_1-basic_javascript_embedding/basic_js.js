inlets = 1; // set the number of inlets
outlets = 1; // set the number of outlets
// global variables
var x = 0.66;
// float -- run the equation once
function msg_float(r)
{
   x = 20 + r;
   outlet(0, x); // send the x result to the outlet
				// first arg is outlet index, second arg is the value
}
// bang -- post the current population to the max window
function bang()
{
   post("the current population is"); // use post method to debug and see vars in Max Console window
   post(x);
   post();
}
