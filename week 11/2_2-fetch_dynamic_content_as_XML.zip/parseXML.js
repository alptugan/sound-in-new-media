autowatch = 1;
inlets = 1;
outlets = 3;
outlet 
var earthquakesDict = new Dict("data1");



function bang() {
	var eqs = earthquakesDict.get("body::xmlroot::children[0]::children[0]::children");
	var magnitudes = [];
	var tag_texts = [];
	for(var key in eqs) {
		var magnitude = earthquakesDict.get("body::xmlroot::children[0]::children[0]::children[" + key + "]::tag_name");
		var tag_text = earthquakesDict.get("body::xmlroot::children[0]::children[0]::children[" + key + "]::tag_text");

		//post(earthquakesDict.get("body::xmlroot::children[0]::children[0]::children[" + key + "]::tag_name"));
		//post(key);
		magnitudes.push(magnitude); 
		tag_texts.push(tag_text); 
		
		outlet(0, key*1 , magnitudes[key], tag_texts[key]);
	}
	post(eqs.length);
	//outlet(0, "Tag Names: ", magnitudes);
	outlet(1, tag_texts);
	outlet(2, post("finished parsing data"));
}
